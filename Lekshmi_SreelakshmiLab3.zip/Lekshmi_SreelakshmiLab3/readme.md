# LAB3 (112001019 , 112001042)
## Directory structure
- Network.py file contains server and client class . It consists few basic functions 
- UAP.py has the encoding decoding part
- AsyncServer.py runs an async server
- ThreadedClient.py runs a threaded client


## To Run
```
python3 A/AsyncServer.py host port
python3 A/ThreadedClient.py port
```

